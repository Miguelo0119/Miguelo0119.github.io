# Sorteo al mejor disfraz de Halloween

Página web para que la familia se inscriba con su disfraz y vote por el mejor, **sin crear cuentas ni iniciar sesión**. Todo se guarda en una hoja de Google que el organizador controla.

## Cómo funciona

```
Celular de cada familiar
        │
        ▼
  index.html (Vercel)  ──►  /api/* (función en Go, Vercel)  ──►  Google Sheets
                                                                 ├─ Evento    (tú lo editas)
                                                                 ├─ Inscritos (lo llena la página)
                                                                 └─ Votos     (lo llena la página)
```

- **Inscripción:** nombre completo (mínimo nombre y apellido), disfraz y una frase de más de 10 letras sobre por qué le gusta Halloween.
- **Candidatos:** todos los inscritos, con su disfraz.
- **Votar:** se escribe el nombre completo con el que se inscribió (no importan tildes ni mayúsculas). Nadie puede votar por sí mismo.
- **Control del organizador:** en la pestaña `Evento` de la hoja cambias el nombre, la fecha, el lugar, el estado (`pendiente`, `abierta`, `pausada`, `cerrada`), si se muestran los resultados y la regla de desempate.
- **Ganadores:** los dos con más votos. Si un empate afecta los puestos ganadores, la página lo muestra junto con la regla de desempate; nunca elige al azar.

## Estructura

```
sorteo-halloween/
├── index.html                    Página (diseño de Halloween, adaptada a celulares)
├── api/index.go                  Función serverless: /api/estado, /api/registro, /api/verificar, /api/votar
├── core/core.go                  Reglas del concurso (validación, duplicados, conteo, ganadores)
├── core/core_test.go             Pruebas unitarias de las reglas
├── sheets/sheets.go              Cliente mínimo de Google Sheets (solo librería estándar de Go)
├── vercel.json                   Rutas y cabeceras de seguridad
├── go.mod
├── .env.example                  Variables de entorno necesarias
└── plantilla-google-sheets.xlsx  Plantilla de la hoja con las tres pestañas
```

No hay dependencias externas de Go: la autenticación con Google (JWT de cuenta de servicio) está hecha con la librería estándar.

## Paso a paso para ponerlo en línea

### 1. Crear la hoja de Google

1. En Google Drive: **Nuevo > Hoja de cálculo de Google**.
2. **Archivo > Importar > Subir** y elige `plantilla-google-sheets.xlsx`. Selecciona **Reemplazar hoja de cálculo**.
3. Verifica que existan las pestañas `Evento`, `Inscritos` y `Votos` con esos nombres exactos.
4. Copia el **ID** de la hoja: es la parte larga de la URL entre `/d/` y `/edit`.

### 2. Crear la cuenta de servicio de Google

Es un "usuario robot" que la página usa para leer y escribir en la hoja.

1. Entra a [Google Cloud Console](https://console.cloud.google.com/) y crea un proyecto (por ejemplo, `sorteo-halloween`).
2. En **APIs y servicios > Biblioteca**, busca **Google Sheets API** y habilítala.
3. En **IAM y administración > Cuentas de servicio**, crea una cuenta. No necesita roles.
4. Entra a la cuenta, pestaña **Claves > Agregar clave > Crear clave nueva > JSON**. Se descarga un archivo `.json`. **Guárdalo en un lugar seguro y nunca lo subas a GitHub.**
5. Copia el correo de la cuenta de servicio (termina en `iam.gserviceaccount.com`).
6. Vuelve a tu hoja, toca **Compartir** y agrega ese correo como **Editor**.

### 3. Subir el proyecto a GitHub

```bash
cd sorteo-halloween
git init
git add .
git commit -m "Sorteo de disfraces de Halloween"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/sorteo-halloween.git
git push -u origin main
```

El archivo `.gitignore` ya evita subir `.env` y archivos de credenciales.

### 4. Desplegar en Vercel

1. En [vercel.com](https://vercel.com), **Add New > Project** e importa el repositorio.
2. Framework Preset: **Other**. No cambies los comandos de build.
3. En **Environment Variables** agrega:

| Variable | Valor |
|---|---|
| `SHEET_ID` | El ID de la hoja del paso 1 |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | El contenido completo del archivo `.json` del paso 2 (o el mismo contenido en base64) |
| `EVENT_CODE` | Opcional. Si lo defines, se pedirá al inscribirse. Déjalo vacío para no pedir código |

4. Toca **Deploy**. Al terminar, Vercel te da la dirección pública de la página.
5. Abre `https://TU-PROYECTO.vercel.app/api/estado`: debe mostrar un JSON con el evento. Si muestra un error, revisa los logs de la función en Vercel (normalmente es el ID de la hoja o que no compartiste la hoja con la cuenta de servicio).

Si cambias una variable de entorno, haz **Redeploy** para que se aplique.

## Probar en tu computador

Pruebas de las reglas (requiere Go 1.22 o superior):

```bash
go test ./...
```

Correr todo localmente con la CLI de Vercel:

```bash
npm i -g vercel
cp .env.example .env    # y llena los valores reales
vercel dev
```

## Cómo se protege la integridad sin cuentas

Google Sheets no tiene restricciones de unicidad ni transacciones, así que la protección está en el código:

- **Antes de escribir**, la API lee la hoja fresca (sin caché) y rechaza nombres repetidos, votos dobles, votos por uno mismo y votos con la votación cerrada.
- **Al contar**, aunque dos solicitudes simultáneas lograran escribir dos filas, solo cuenta la **primera** inscripción de cada nombre y el **primer** voto de cada persona. Por eso nunca borres ni reordenes filas en `Votos`.
- Los textos se guardan como texto plano (`RAW`): un nombre que empiece por `=` nunca se ejecuta como fórmula.
- Límite de 20 escrituras por minuto por dirección IP y cuerpo de solicitud máximo de 4 KB.
- Los errores técnicos solo quedan en los logs de Vercel; al navegador llegan mensajes claros sin detalles internos.

### Riesgos conocidos (y decisiones conscientes)

- **Votar solo con el nombre:** quien sepa tu nombre completo podría votar por ti antes que tú. Si pasa, la página le dirá al verdadero dueño que "este nombre ya votó" y podrás revisar la pestaña `Votos`. `EVENT_CODE` ayuda a que solo voten quienes están en la fiesta.
- **Doble inscripción con nombres distintos:** alguien podría inscribirse dos veces con nombres diferentes. Revisa la pestaña `Inscritos` y escribe `NO` en `activo` para retirar a quien sobre; sus votos dejan de contar.
- **Límites de Google:** la API de Sheets limita las solicitudes por minuto. La página guarda en caché las lecturas por unos segundos, pero si toda la familia vota en el mismo instante alguien podría ver "espera unos segundos". Basta con volver a intentar.
- **Edición manual:** cualquiera con acceso de edición a la hoja puede alterar votos. Comparte la hoja solo con la cuenta de servicio y contigo.
- **Privacidad:** nombres, disfraces y frases son visibles en la página. No se piden documentos ni correos. Al terminar el evento, borra la hoja o sus pestañas `Inscritos` y `Votos`, y elimina la clave de la cuenta de servicio en Google Cloud.

## Lista de comprobación para el día del evento

- [ ] `/api/estado` responde con el evento correcto.
- [ ] Hiciste una inscripción de prueba y luego la retiraste con `NO` en `activo`.
- [ ] La regla de desempate está escrita en `Evento` antes de abrir.
- [ ] `estado` cambiado a `abierta` unos minutos antes de anunciarlo.
- [ ] Al terminar: `estado` en `cerrada` y luego `mostrar_resultados` en `SI`.
- [ ] Después del evento: borrar datos y la clave de la cuenta de servicio.
