// Package handler es la función serverless de Vercel. Una sola función atiende todas las rutas
// (/api/estado, /api/registro, /api/verificar, /api/votar) gracias a las reescrituras de vercel.json.
package handler

import (
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"log"
	"net"
	"net/http"
	"os"
	"path"
	"strings"
	"sync"
	"time"

	"sorteo/core"
	"sorteo/sheets"
)

const (
	rangoEvento    = "Evento!A:B"
	rangoInscritos = "Inscritos!A:H"
	rangoVotos     = "Votos!A:E"
	cacheTTL       = 8 * time.Second // reduce lecturas a Google cuando muchos abren la página a la vez
)

// ---------- Estado compartido dentro de una instancia ----------

var (
	cliOnce sync.Once
	cli     *sheets.Client
	cliErr  error

	cacheMu sync.Mutex
	cache   *foto
	cacheAt time.Time

	// Serializa las escrituras dentro de la misma instancia. Entre instancias distintas no hay
	// candado: por eso las reglas de core ignoran duplicados al contar (gana la primera fila).
	escrituraMu sync.Mutex

	limiteMu sync.Mutex
	limite   = map[string][]time.Time{}
)

type foto struct {
	ev    core.Evento
	ins   []core.Participante
	votos []core.Voto
}

func cliente() (*sheets.Client, error) {
	cliOnce.Do(func() {
		cli, cliErr = sheets.New(os.Getenv("GOOGLE_SERVICE_ACCOUNT_JSON"), os.Getenv("SHEET_ID"))
		if cliErr != nil {
			log.Printf("configuración: %v", cliErr)
		}
	})
	return cli, cliErr
}

// leer trae la hoja completa. fresco=true ignora el caché (se usa antes de escribir).
func leer(ctx context.Context, fresco bool) (*foto, error) {
	cacheMu.Lock()
	if !fresco && cache != nil && time.Since(cacheAt) < cacheTTL {
		f := cache
		cacheMu.Unlock()
		return f, nil
	}
	cacheMu.Unlock()

	c, err := cliente()
	if err != nil {
		return nil, err
	}
	datos, err := c.BatchGet(ctx, rangoEvento, rangoInscritos, rangoVotos)
	if err != nil {
		return nil, err
	}
	f := &foto{
		ev:    core.ParseEvento(datos[0]),
		ins:   core.ParseInscritos(datos[1]),
		votos: core.ParseVotos(datos[2]),
	}
	cacheMu.Lock()
	cache, cacheAt = f, time.Now()
	cacheMu.Unlock()
	return f, nil
}

func invalidar() {
	cacheMu.Lock()
	cache = nil
	cacheMu.Unlock()
}

// ---------- Utilidades HTTP ----------

type errorAPI struct {
	Status  int               `json:"-"`
	Mensaje string            `json:"error"`
	Campos  map[string]string `json:"campos,omitempty"`
}

func responder(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func fallar(w http.ResponseWriter, e errorAPI) { responder(w, e.Status, e) }

func errorInterno(w http.ResponseWriter, err error) {
	// Nunca devolvemos el detalle técnico al navegador; solo queda en los logs de Vercel.
	log.Printf("error interno: %v", err)
	if errors.Is(err, sheets.ErrLimite) {
		fallar(w, errorAPI{Status: http.StatusServiceUnavailable, Mensaje: "Hay mucha gente votando al mismo tiempo. Espera unos segundos e intenta de nuevo."})
		return
	}
	fallar(w, errorAPI{Status: http.StatusInternalServerError, Mensaje: "Algo falló al guardar. Intenta de nuevo en un momento."})
}

func leerJSON(w http.ResponseWriter, r *http.Request, dst any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 4<<10)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}

func ipCliente(r *http.Request) string {
	if xf := r.Header.Get("X-Forwarded-For"); xf != "" {
		return strings.TrimSpace(strings.Split(xf, ",")[0])
	}
	host, _, _ := net.SplitHostPort(r.RemoteAddr)
	return host
}

// permitido aplica un límite simple de 20 solicitudes de escritura por minuto por IP (por instancia).
func permitido(r *http.Request) bool {
	ip := ipCliente(r)
	ahora := time.Now()
	limiteMu.Lock()
	defer limiteMu.Unlock()
	var recientes []time.Time
	for _, t := range limite[ip] {
		if ahora.Sub(t) < time.Minute {
			recientes = append(recientes, t)
		}
	}
	if len(recientes) >= 20 {
		limite[ip] = recientes
		return false
	}
	limite[ip] = append(recientes, ahora)
	return true
}

func nuevoID() string {
	b := make([]byte, 6)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func ahora() string { return time.Now().UTC().Format(time.RFC3339) }

// ---------- Router ----------

// Handler es el punto de entrada que Vercel invoca.
func Handler(w http.ResponseWriter, r *http.Request) {
	ruta := r.URL.Query().Get("ruta")
	if ruta == "" {
		ruta = path.Base(r.URL.Path)
	}
	if r.Method != http.MethodGet && r.Method != http.MethodPost {
		fallar(w, errorAPI{Status: http.StatusMethodNotAllowed, Mensaje: "Método no permitido."})
		return
	}
	if r.Method == http.MethodPost {
		if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
			fallar(w, errorAPI{Status: http.StatusUnsupportedMediaType, Mensaje: "Formato no válido."})
			return
		}
		if !permitido(r) {
			fallar(w, errorAPI{Status: http.StatusTooManyRequests, Mensaje: "Demasiados intentos. Espera un minuto."})
			return
		}
	}
	switch {
	case ruta == "estado" && r.Method == http.MethodGet:
		estado(w, r)
	case ruta == "registro" && r.Method == http.MethodPost:
		registro(w, r)
	case ruta == "verificar" && r.Method == http.MethodPost:
		verificar(w, r)
	case ruta == "votar" && r.Method == http.MethodPost:
		votar(w, r)
	default:
		fallar(w, errorAPI{Status: http.StatusNotFound, Mensaje: "Ruta no encontrada."})
	}
}

// ---------- GET /api/estado ----------

type candidatoPublico struct {
	ID      string `json:"id"`
	Nombre  string `json:"nombre"`
	Disfraz string `json:"disfraz"`
	Frase   string `json:"frase"`
	Foto    string `json:"foto,omitempty"`
}

type resultadosPublicos struct {
	Conteo     []core.Resultado `json:"conteo"`
	Ganadores  []core.Resultado `json:"ganadores"`
	Empate     *core.Empate     `json:"empate,omitempty"`
	TotalVotos int              `json:"totalVotos"`
}

func estado(w http.ResponseWriter, r *http.Request) {
	f, err := leer(r.Context(), false)
	if err != nil {
		errorInterno(w, err)
		return
	}
	cands := make([]candidatoPublico, 0, len(f.ins))
	for _, p := range f.ins {
		cands = append(cands, candidatoPublico{ID: p.ID, Nombre: p.Nombre, Disfraz: p.Disfraz, Frase: p.Frase, Foto: p.FotoURL})
	}
	var res *resultadosPublicos
	if f.ev.MostrarResultados {
		conteo, total := core.Contar(f.ins, f.votos)
		g, e := core.Ganadores(conteo, 2)
		res = &resultadosPublicos{Conteo: conteo, Ganadores: g, Empate: e, TotalVotos: total}
	}
	responder(w, http.StatusOK, map[string]any{
		"evento":         f.ev,
		"candidatos":     cands,
		"inscritos":      len(f.ins),
		"requiereCodigo": os.Getenv("EVENT_CODE") != "",
		"resultados":     res,
	})
}

// ---------- POST /api/registro ----------

func codigoValido(enviado string) bool {
	esperado := os.Getenv("EVENT_CODE")
	if esperado == "" {
		return true
	}
	return subtle.ConstantTimeCompare([]byte(strings.TrimSpace(enviado)), []byte(esperado)) == 1
}

func registro(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Nombre  string `json:"nombre"`
		Disfraz string `json:"disfraz"`
		Frase   string `json:"frase"`
		Codigo  string `json:"codigo"`
	}
	if err := leerJSON(w, r, &in); err != nil {
		fallar(w, errorAPI{Status: http.StatusBadRequest, Mensaje: "Datos no válidos."})
		return
	}
	nombre := core.LimpiarTexto(in.Nombre, 80)
	disfraz := core.LimpiarTexto(in.Disfraz, 60)
	frase := core.LimpiarTexto(in.Frase, 200)
	if campos := core.ValidarRegistro(nombre, disfraz, frase); len(campos) > 0 {
		fallar(w, errorAPI{Status: http.StatusUnprocessableEntity, Mensaje: "Revisa los datos marcados.", Campos: campos})
		return
	}
	if !codigoValido(in.Codigo) {
		fallar(w, errorAPI{Status: http.StatusForbidden, Mensaje: "El código del evento no es correcto.", Campos: map[string]string{"codigo": "Pregunta el código a quien organiza."}})
		return
	}

	escrituraMu.Lock()
	defer escrituraMu.Unlock()
	f, err := leer(r.Context(), true)
	if err != nil {
		errorInterno(w, err)
		return
	}
	if f.ev.Estado == "cerrada" {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "La votación ya cerró. Ya no se reciben inscripciones."})
		return
	}
	if _, existe := core.BuscarPorNombre(f.ins, nombre); existe {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "Ya hay alguien inscrito con ese nombre.",
			Campos: map[string]string{"nombre": "Ya hay alguien inscrito con ese nombre. Si eres tú, ve a Votar. Si no, agrega tu segundo apellido."}})
		return
	}
	c, _ := cliente()
	fila := []string{ahora(), nuevoID(), nombre, core.NormalizarNombre(nombre), disfraz, frase, "", "SI"}
	if err := c.Append(r.Context(), rangoInscritos, [][]string{fila}); err != nil {
		errorInterno(w, err)
		return
	}
	invalidar()
	responder(w, http.StatusCreated, map[string]any{"ok": true, "nombre": nombre})
}

// ---------- POST /api/verificar ----------
// Confirma, antes de mostrar la boleta, que el nombre está inscrito y aún no ha votado.

func verificar(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Nombre string `json:"nombre"`
	}
	if err := leerJSON(w, r, &in); err != nil {
		fallar(w, errorAPI{Status: http.StatusBadRequest, Mensaje: "Datos no válidos."})
		return
	}
	f, err := leer(r.Context(), true)
	if err != nil {
		errorInterno(w, err)
		return
	}
	if f.ev.Estado != "abierta" {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "La votación no está abierta en este momento."})
		return
	}
	p, ok := core.BuscarPorNombre(f.ins, in.Nombre)
	if !ok {
		fallar(w, errorAPI{Status: http.StatusNotFound, Mensaje: "No encontramos ese nombre entre los inscritos. Escríbelo igual que al inscribirte, o inscríbete primero."})
		return
	}
	if core.YaVoto(f.ins, f.votos, p.ID) {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "Este nombre ya votó. Si no fuiste tú, avísale a quien organiza."})
		return
	}
	responder(w, http.StatusOK, map[string]any{"ok": true, "id": p.ID, "nombre": p.Nombre})
}

// ---------- POST /api/votar ----------

func votar(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Nombre      string `json:"nombre"`
		CandidatoID string `json:"candidatoId"`
	}
	if err := leerJSON(w, r, &in); err != nil {
		fallar(w, errorAPI{Status: http.StatusBadRequest, Mensaje: "Datos no válidos."})
		return
	}
	escrituraMu.Lock()
	defer escrituraMu.Unlock()
	f, err := leer(r.Context(), true)
	if err != nil {
		errorInterno(w, err)
		return
	}
	if f.ev.Estado != "abierta" {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "La votación no está abierta en este momento."})
		return
	}
	votante, ok := core.BuscarPorNombre(f.ins, in.Nombre)
	if !ok {
		fallar(w, errorAPI{Status: http.StatusNotFound, Mensaje: "No encontramos ese nombre entre los inscritos."})
		return
	}
	cand, ok := core.BuscarPorID(f.ins, in.CandidatoID)
	if !ok {
		fallar(w, errorAPI{Status: http.StatusUnprocessableEntity, Mensaje: "Ese disfraz ya no está disponible. Elige otro."})
		return
	}
	if cand.ID == votante.ID {
		fallar(w, errorAPI{Status: http.StatusUnprocessableEntity, Mensaje: "No puedes votar por tu propio disfraz."})
		return
	}
	if core.YaVoto(f.ins, f.votos, votante.ID) {
		fallar(w, errorAPI{Status: http.StatusConflict, Mensaje: "Este nombre ya votó. Solo se permite un voto por persona."})
		return
	}
	c, _ := cliente()
	fila := []string{ahora(), votante.ID, votante.Nombre, cand.ID, cand.Nombre}
	if err := c.Append(r.Context(), rangoVotos, [][]string{fila}); err != nil {
		errorInterno(w, err)
		return
	}
	invalidar()
	responder(w, http.StatusCreated, map[string]any{"ok": true, "candidato": cand.Nombre})
}
