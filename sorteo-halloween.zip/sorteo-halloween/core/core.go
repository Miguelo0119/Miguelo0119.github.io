// Package core contiene las reglas del concurso, sin depender de Google Sheets ni de HTTP.
// Así se pueden probar con `go test ./...`.
package core

import (
	"sort"
	"strings"
	"unicode"
)

// ---------- Modelos ----------

// Evento son los datos que el organizador escribe en la pestaña "Evento".
type Evento struct {
	Nombre            string `json:"nombre"`
	Descripcion       string `json:"descripcion"`
	Fecha             string `json:"fecha"`
	Lugar             string `json:"lugar"`
	Estado            string `json:"estado"` // pendiente | abierta | pausada | cerrada
	MostrarResultados bool   `json:"-"`
	Desempate         string `json:"desempate"`
}

// Participante es una fila de la pestaña "Inscritos". Todos los inscritos son candidatos.
type Participante struct {
	ID         string
	Nombre     string
	NombreNorm string
	Disfraz    string
	Frase      string
	FotoURL    string
	Activo     bool
	Fila       int
}

// Voto es una fila de la pestaña "Votos".
type Voto struct {
	VotanteID   string
	CandidatoID string
	Fila        int
}

// Resultado es el conteo de un candidato.
type Resultado struct {
	ID      string `json:"id"`
	Nombre  string `json:"nombre"`
	Disfraz string `json:"disfraz"`
	FotoURL string `json:"foto,omitempty"`
	Votos   int    `json:"votos"`
}

// Empate describe un empate que afecta a los puestos ganadores.
type Empate struct {
	Empatados []Resultado `json:"empatados"`
	Puestos   int         `json:"puestos"`
	Votos     int         `json:"votos"`
}

// ---------- Normalización y validación ----------

var acentos = strings.NewReplacer(
	"á", "a", "à", "a", "ä", "a", "â", "a", "ã", "a",
	"é", "e", "è", "e", "ë", "e", "ê", "e",
	"í", "i", "ì", "i", "ï", "i", "î", "i",
	"ó", "o", "ò", "o", "ö", "o", "ô", "o", "õ", "o",
	"ú", "u", "ù", "u", "ü", "u", "û", "u",
	"ñ", "n", "ç", "c",
)

// NormalizarNombre convierte "  María  José PEÑA " en "maria jose pena" para comparar nombres
// sin que importen mayúsculas, tildes ni espacios extra.
func NormalizarNombre(s string) string {
	s = acentos.Replace(strings.ToLower(strings.TrimSpace(s)))
	var b strings.Builder
	for _, r := range s {
		switch {
		case unicode.IsLetter(r):
			b.WriteRune(r)
		case unicode.IsSpace(r), r == '-', r == '\'':
			b.WriteRune(' ')
		}
	}
	return strings.Join(strings.Fields(b.String()), " ")
}

// LimpiarTexto quita espacios repetidos y recorta el largo máximo.
func LimpiarTexto(s string, max int) string {
	s = strings.Join(strings.Fields(s), " ")
	r := []rune(s)
	if len(r) > max {
		r = r[:max]
	}
	return string(r)
}

// ContarLetras cuenta solo letras (no espacios, números ni signos).
func ContarLetras(s string) int {
	n := 0
	for _, r := range s {
		if unicode.IsLetter(r) {
			n++
		}
	}
	return n
}

// ValidarRegistro devuelve un mapa campo -> mensaje. Vacío significa válido.
func ValidarRegistro(nombre, disfraz, frase string) map[string]string {
	e := map[string]string{}
	if nombre == "" {
		e["nombre"] = "Escribe tu nombre completo."
	} else {
		ok := true
		for _, r := range nombre {
			if !(unicode.IsLetter(r) || r == ' ' || r == '\'' || r == '-') {
				ok = false
				break
			}
		}
		palabras := strings.Fields(nombre)
		cortas := false
		for _, p := range palabras {
			if ContarLetras(p) < 2 {
				cortas = true
			}
		}
		switch {
		case !ok:
			e["nombre"] = "Usa solo letras en tu nombre."
		case len(palabras) < 2 || cortas:
			e["nombre"] = "Escribe al menos un nombre y un apellido."
		}
	}
	if ContarLetras(disfraz) < 3 {
		e["disfraz"] = "Cuéntanos de qué vas disfrazado."
	}
	if ContarLetras(frase) <= 10 {
		e["frase"] = "Escribe una frase con más de 10 letras."
	}
	return e
}

// ---------- Lectura de las pestañas ----------

func celda(fila []string, i int) string {
	if i < len(fila) {
		return strings.TrimSpace(fila[i])
	}
	return ""
}

func esNo(s string) bool {
	s = NormalizarNombre(s)
	return s == "no" || s == "falso" || s == "false" || s == "0"
}

func esSi(s string) bool {
	s = NormalizarNombre(s)
	return s == "si" || s == "verdadero" || s == "true" || s == "1"
}

// ParseEvento lee la pestaña "Evento" (columna A: clave, columna B: valor).
func ParseEvento(filas [][]string) Evento {
	ev := Evento{Nombre: "Sorteo al mejor disfraz de Halloween", Estado: "pendiente"}
	for _, f := range filas {
		clave, valor := NormalizarNombre(strings.ReplaceAll(celda(f, 0), "_", " ")), celda(f, 1)
		switch strings.ReplaceAll(clave, " ", "_") {
		case "nombre":
			if valor != "" {
				ev.Nombre = valor
			}
		case "descripcion":
			ev.Descripcion = valor
		case "fecha":
			ev.Fecha = valor
		case "lugar":
			ev.Lugar = valor
		case "estado":
			switch NormalizarNombre(valor) {
			case "abierta", "abierto":
				ev.Estado = "abierta"
			case "pausada", "pausado":
				ev.Estado = "pausada"
			case "cerrada", "cerrado":
				ev.Estado = "cerrada"
			default:
				ev.Estado = "pendiente"
			}
		case "mostrar_resultados":
			ev.MostrarResultados = esSi(valor)
		case "desempate":
			ev.Desempate = valor
		}
	}
	return ev
}

// ParseInscritos lee la pestaña "Inscritos" (la primera fila son encabezados).
// Columnas: fecha | id | nombre | nombre_normalizado | disfraz | frase | foto_url | activo
//
// Si un mismo nombre aparece varias veces (por ejemplo, dos registros simultáneos),
// gana la PRIMERA fila activa y las demás se ignoran. Así la hoja nunca produce duplicados efectivos.
func ParseInscritos(filas [][]string) []Participante {
	vistos := map[string]bool{}
	ids := map[string]bool{}
	var out []Participante
	for i, f := range filas {
		if i == 0 {
			continue
		}
		p := Participante{
			ID:      celda(f, 1),
			Nombre:  celda(f, 2),
			Disfraz: celda(f, 4),
			Frase:   celda(f, 5),
			FotoURL: celda(f, 6),
			Activo:  !esNo(celda(f, 7)),
			Fila:    i + 1,
		}
		p.NombreNorm = NormalizarNombre(p.Nombre)
		if p.ID == "" || p.NombreNorm == "" || !p.Activo || vistos[p.NombreNorm] || ids[p.ID] {
			continue
		}
		if !strings.HasPrefix(p.FotoURL, "https://") {
			p.FotoURL = ""
		}
		vistos[p.NombreNorm] = true
		ids[p.ID] = true
		out = append(out, p)
	}
	return out
}

// ParseVotos lee la pestaña "Votos" (la primera fila son encabezados).
// Columnas: fecha | votante_id | votante_nombre | candidato_id | candidato_nombre
func ParseVotos(filas [][]string) []Voto {
	var out []Voto
	for i, f := range filas {
		if i == 0 {
			continue
		}
		v := Voto{VotanteID: celda(f, 1), CandidatoID: celda(f, 3), Fila: i + 1}
		if v.VotanteID != "" && v.CandidatoID != "" {
			out = append(out, v)
		}
	}
	return out
}

// ---------- Reglas ----------

// BuscarPorNombre encuentra a un inscrito activo por su nombre, sin importar tildes ni mayúsculas.
func BuscarPorNombre(ins []Participante, nombre string) (Participante, bool) {
	n := NormalizarNombre(nombre)
	for _, p := range ins {
		if p.NombreNorm == n {
			return p, true
		}
	}
	return Participante{}, false
}

// BuscarPorID encuentra a un inscrito activo por su id.
func BuscarPorID(ins []Participante, id string) (Participante, bool) {
	for _, p := range ins {
		if p.ID == id {
			return p, true
		}
	}
	return Participante{}, false
}

// VotosValidos aplica las reglas de conteo:
//   - solo cuenta el PRIMER voto de cada votante (si dos llegan casi al tiempo, el segundo se ignora);
//   - el votante y el candidato deben ser inscritos activos;
//   - nadie puede votar por sí mismo.
func VotosValidos(ins []Participante, votos []Voto) []Voto {
	activos := map[string]bool{}
	for _, p := range ins {
		activos[p.ID] = true
	}
	ya := map[string]bool{}
	var out []Voto
	for _, v := range votos {
		if ya[v.VotanteID] || !activos[v.VotanteID] || !activos[v.CandidatoID] || v.VotanteID == v.CandidatoID {
			continue
		}
		ya[v.VotanteID] = true
		out = append(out, v)
	}
	return out
}

// YaVoto indica si el votante tiene un voto válido.
func YaVoto(ins []Participante, votos []Voto, votanteID string) bool {
	for _, v := range VotosValidos(ins, votos) {
		if v.VotanteID == votanteID {
			return true
		}
	}
	return false
}

// Contar devuelve el conteo por candidato (todos los inscritos, incluso con 0 votos)
// ordenado de mayor a menor, y el total de votos válidos.
func Contar(ins []Participante, votos []Voto) ([]Resultado, int) {
	idx := map[string]int{}
	res := make([]Resultado, 0, len(ins))
	for _, p := range ins {
		idx[p.ID] = len(res)
		res = append(res, Resultado{ID: p.ID, Nombre: p.Nombre, Disfraz: p.Disfraz, FotoURL: p.FotoURL})
	}
	validos := VotosValidos(ins, votos)
	for _, v := range validos {
		res[idx[v.CandidatoID]].Votos++
	}
	sort.SliceStable(res, func(i, j int) bool {
		if res[i].Votos != res[j].Votos {
			return res[i].Votos > res[j].Votos
		}
		return res[i].Nombre < res[j].Nombre // solo para mostrar; nunca decide un empate
	})
	return res, len(validos)
}

// Ganadores elige los `puestos` primeros. Si un empate afecta el último puesto ganador,
// devuelve solo los ganadores seguros y describe el empate: el sistema NUNCA elige al azar.
func Ganadores(orden []Resultado, puestos int) ([]Resultado, *Empate) {
	if len(orden) <= puestos {
		return orden, nil
	}
	corte, siguiente := orden[puestos-1].Votos, orden[puestos].Votos
	if corte > siguiente {
		return orden[:puestos], nil
	}
	var seguros, empatados []Resultado
	for _, r := range orden {
		switch {
		case r.Votos > corte:
			seguros = append(seguros, r)
		case r.Votos == corte:
			empatados = append(empatados, r)
		}
	}
	return seguros, &Empate{Empatados: empatados, Puestos: puestos - len(seguros), Votos: corte}
}
