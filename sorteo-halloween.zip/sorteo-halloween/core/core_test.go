package core

import "testing"

func TestNormalizarNombre(t *testing.T) {
	casos := map[string]string{
		"  María  José PEÑA ": "maria jose pena",
		"ANA-MARÍA o'neil":    "ana maria o neil",
		"Luis   Gómez":        "luis gomez",
	}
	for in, want := range casos {
		if got := NormalizarNombre(in); got != want {
			t.Errorf("NormalizarNombre(%q) = %q, quería %q", in, got, want)
		}
	}
}

func TestValidarRegistro(t *testing.T) {
	if e := ValidarRegistro("Carlos Pérez", "Momia", "Me encantan los dulces"); len(e) != 0 {
		t.Fatalf("registro válido rechazado: %v", e)
	}
	e := ValidarRegistro("Carlos", "Mo", "Me gusta")
	for _, campo := range []string{"nombre", "disfraz", "frase"} {
		if e[campo] == "" {
			t.Errorf("debía fallar el campo %s", campo)
		}
	}
	if e := ValidarRegistro("Carlos P3rez", "Momia", "Me encantan los dulces"); e["nombre"] == "" {
		t.Error("debía rechazar números en el nombre")
	}
	// Exactamente 10 letras no basta; 11 sí.
	if e := ValidarRegistro("Ana Ruiz", "Bruja", "abcde fghij"); e["frase"] == "" {
		t.Error("10 letras no debería bastar")
	}
	if e := ValidarRegistro("Ana Ruiz", "Bruja", "abcde fghijk"); e["frase"] != "" {
		t.Error("11 letras debería bastar")
	}
}

var hdr = []string{"fecha", "id", "nombre", "nombre_normalizado", "disfraz", "frase", "foto_url", "activo"}

func TestParseInscritosDuplicados(t *testing.T) {
	filas := [][]string{
		hdr,
		{"t", "a1", "Ana Ruiz", "", "Bruja", "x", "", "SI"},
		{"t", "a2", "ana  ruíz", "", "Gato", "x", "", "SI"}, // mismo nombre normalizado: se ignora
		{"t", "b1", "Beto Díaz", "", "Vampiro", "x", "", "NO"}, // inactivo: se ignora
		{"t", "c1", "Caro León", "", "Calabaza", "x", "http://inseguro", ""},
	}
	ins := ParseInscritos(filas)
	if len(ins) != 2 || ins[0].ID != "a1" || ins[1].ID != "c1" {
		t.Fatalf("inscritos efectivos inesperados: %+v", ins)
	}
	if ins[1].FotoURL != "" {
		t.Error("las fotos sin https deben descartarse")
	}
}

func TestVotosValidos(t *testing.T) {
	ins := []Participante{{ID: "a"}, {ID: "b"}, {ID: "c"}}
	votos := []Voto{
		{VotanteID: "a", CandidatoID: "b"},
		{VotanteID: "a", CandidatoID: "c"}, // segundo voto de "a": se ignora
		{VotanteID: "b", CandidatoID: "b"}, // voto por sí mismo: se ignora
		{VotanteID: "x", CandidatoID: "a"}, // votante no inscrito: se ignora
		{VotanteID: "c", CandidatoID: "z"}, // candidato inexistente: se ignora
		{VotanteID: "c", CandidatoID: "b"},
	}
	v := VotosValidos(ins, votos)
	if len(v) != 2 {
		t.Fatalf("quería 2 votos válidos, obtuve %d: %+v", len(v), v)
	}
	if !YaVoto(ins, votos, "a") || YaVoto(ins, votos, "b") {
		t.Error("YaVoto calculó mal")
	}
}

func TestGanadoresSinEmpate(t *testing.T) {
	orden := []Resultado{{ID: "A", Votos: 24}, {ID: "B", Votos: 19}, {ID: "C", Votos: 12}, {ID: "D", Votos: 7}}
	g, e := Ganadores(orden, 2)
	if e != nil || len(g) != 2 || g[0].ID != "A" || g[1].ID != "B" {
		t.Fatalf("ganadores inesperados: %+v %+v", g, e)
	}
}

func TestGanadoresEmpateSegundoPuesto(t *testing.T) {
	orden := []Resultado{{ID: "A", Votos: 10}, {ID: "B", Votos: 6}, {ID: "C", Votos: 6}, {ID: "D", Votos: 2}}
	g, e := Ganadores(orden, 2)
	if len(g) != 1 || g[0].ID != "A" || e == nil || e.Puestos != 1 || len(e.Empatados) != 2 {
		t.Fatalf("empate mal detectado: %+v %+v", g, e)
	}
}

func TestGanadoresEmpateTriple(t *testing.T) {
	orden := []Resultado{{ID: "A", Votos: 5}, {ID: "B", Votos: 5}, {ID: "C", Votos: 5}}
	g, e := Ganadores(orden, 2)
	if len(g) != 0 || e == nil || e.Puestos != 2 || len(e.Empatados) != 3 {
		t.Fatalf("empate triple mal detectado: %+v %+v", g, e)
	}
}

func TestContar(t *testing.T) {
	ins := []Participante{{ID: "a", Nombre: "Ana"}, {ID: "b", Nombre: "Beto"}, {ID: "c", Nombre: "Caro"}}
	votos := []Voto{{VotanteID: "a", CandidatoID: "b"}, {VotanteID: "c", CandidatoID: "b"}, {VotanteID: "b", CandidatoID: "a"}}
	res, total := Contar(ins, votos)
	if total != 3 || res[0].ID != "b" || res[0].Votos != 2 || res[2].Votos != 0 {
		t.Fatalf("conteo inesperado: %+v total=%d", res, total)
	}
}

func TestParseEvento(t *testing.T) {
	ev := ParseEvento([][]string{{"clave", "valor"}, {"Estado", "Abierta"}, {"mostrar_resultados", "Sí"}, {"Nombre", "Fiesta"}})
	if ev.Estado != "abierta" || !ev.MostrarResultados || ev.Nombre != "Fiesta" {
		t.Fatalf("evento mal leído: %+v", ev)
	}
}
