module sorteo

go 1.22
