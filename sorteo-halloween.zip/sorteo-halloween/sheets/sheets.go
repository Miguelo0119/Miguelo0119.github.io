// Package sheets es un cliente mínimo de la API de Google Sheets que usa solo la librería
// estándar de Go (sin dependencias externas): autenticación con cuenta de servicio (JWT RS256),
// lectura de rangos y agregado de filas.
package sheets

import (
	"bytes"
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

const (
	scope    = "https://www.googleapis.com/auth/spreadsheets"
	tokenURL = "https://oauth2.googleapis.com/token"
	apiBase  = "https://sheets.googleapis.com/v4/spreadsheets/"
)

// Client habla con una sola hoja de cálculo.
type Client struct {
	email   string
	key     *rsa.PrivateKey
	sheetID string
	http    *http.Client

	mu    sync.Mutex
	token string
	exp   time.Time
}

// New crea un cliente a partir del JSON de la cuenta de servicio (tal cual o en base64).
func New(credenciales, sheetID string) (*Client, error) {
	credenciales = strings.TrimSpace(credenciales)
	if credenciales == "" || sheetID == "" {
		return nil, errors.New("faltan GOOGLE_SERVICE_ACCOUNT_JSON o SHEET_ID")
	}
	if !strings.HasPrefix(credenciales, "{") {
		dec, err := base64.StdEncoding.DecodeString(credenciales)
		if err != nil {
			return nil, errors.New("GOOGLE_SERVICE_ACCOUNT_JSON no es JSON ni base64 válido")
		}
		credenciales = string(dec)
	}
	var sa struct {
		ClientEmail string `json:"client_email"`
		PrivateKey  string `json:"private_key"`
	}
	if err := json.Unmarshal([]byte(credenciales), &sa); err != nil {
		return nil, errors.New("no se pudo leer el JSON de la cuenta de servicio")
	}
	bloque, _ := pem.Decode([]byte(sa.PrivateKey))
	if bloque == nil {
		return nil, errors.New("la private_key de la cuenta de servicio no es PEM válido")
	}
	var key *rsa.PrivateKey
	if k, err := x509.ParsePKCS8PrivateKey(bloque.Bytes); err == nil {
		rk, ok := k.(*rsa.PrivateKey)
		if !ok {
			return nil, errors.New("la llave de la cuenta de servicio no es RSA")
		}
		key = rk
	} else if k, err := x509.ParsePKCS1PrivateKey(bloque.Bytes); err == nil {
		key = k
	} else {
		return nil, errors.New("no se pudo interpretar la llave de la cuenta de servicio")
	}
	return &Client{
		email:   sa.ClientEmail,
		key:     key,
		sheetID: sheetID,
		http:    &http.Client{Timeout: 10 * time.Second},
	}, nil
}

func b64(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

// accessToken obtiene (y reutiliza mientras sea válido) un token OAuth para la cuenta de servicio.
func (c *Client) accessToken(ctx context.Context) (string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.token != "" && time.Until(c.exp) > time.Minute {
		return c.token, nil
	}
	ahora := time.Now()
	cab, _ := json.Marshal(map[string]string{"alg": "RS256", "typ": "JWT"})
	claims, _ := json.Marshal(map[string]any{
		"iss": c.email, "scope": scope, "aud": tokenURL,
		"iat": ahora.Unix(), "exp": ahora.Add(time.Hour).Unix(),
	})
	sinFirma := b64(cab) + "." + b64(claims)
	h := sha256.Sum256([]byte(sinFirma))
	firma, err := rsa.SignPKCS1v15(rand.Reader, c.key, crypto.SHA256, h[:])
	if err != nil {
		return "", fmt.Errorf("firmando JWT: %w", err)
	}
	form := url.Values{
		"grant_type": {"urn:ietf:params:oauth:grant-type:jwt-bearer"},
		"assertion":  {sinFirma + "." + b64(firma)},
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, tokenURL, strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := c.http.Do(req)
	if err != nil {
		return "", fmt.Errorf("pidiendo token: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("token rechazado por Google (HTTP %d)", resp.StatusCode)
	}
	var tok struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tok); err != nil || tok.AccessToken == "" {
		return "", errors.New("respuesta de token inválida")
	}
	c.token = tok.AccessToken
	c.exp = ahora.Add(time.Duration(tok.ExpiresIn) * time.Second)
	return c.token, nil
}

func (c *Client) do(ctx context.Context, method, u string, body any, out any) error {
	tok, err := c.accessToken(ctx)
	if err != nil {
		return err
	}
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	req, _ := http.NewRequestWithContext(ctx, method, u, rd)
	req.Header.Set("Authorization", "Bearer "+tok)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("llamando a Sheets: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusTooManyRequests {
		return ErrLimite
	}
	if resp.StatusCode/100 != 2 {
		return fmt.Errorf("Sheets respondió HTTP %d", resp.StatusCode)
	}
	if out != nil {
		return json.NewDecoder(resp.Body).Decode(out)
	}
	return nil
}

// ErrLimite indica que Google limitó temporalmente las solicitudes.
var ErrLimite = errors.New("límite de solicitudes de Google Sheets")

// BatchGet lee varios rangos (por ejemplo "Evento!A:B") en una sola llamada.
func (c *Client) BatchGet(ctx context.Context, rangos ...string) ([][][]string, error) {
	q := url.Values{}
	for _, r := range rangos {
		q.Add("ranges", r)
	}
	q.Set("valueRenderOption", "FORMATTED_VALUE")
	var resp struct {
		ValueRanges []struct {
			Values [][]any `json:"values"`
		} `json:"valueRanges"`
	}
	if err := c.do(ctx, http.MethodGet, apiBase+c.sheetID+"/values:batchGet?"+q.Encode(), nil, &resp); err != nil {
		return nil, err
	}
	out := make([][][]string, len(rangos))
	for i := range rangos {
		if i >= len(resp.ValueRanges) {
			continue
		}
		for _, fila := range resp.ValueRanges[i].Values {
			fs := make([]string, len(fila))
			for j, v := range fila {
				fs[j] = fmt.Sprint(v)
			}
			out[i] = append(out[i], fs)
		}
	}
	return out, nil
}

// Append agrega filas al final de un rango. Usa RAW para que Google guarde todo como texto:
// así un nombre que empiece por "=" nunca se ejecuta como fórmula.
func (c *Client) Append(ctx context.Context, rango string, filas [][]string) error {
	u := apiBase + c.sheetID + "/values/" + url.PathEscape(rango) +
		":append?valueInputOption=RAW&insertDataOption=INSERT_ROWS"
	return c.do(ctx, http.MethodPost, u, map[string]any{"values": filas}, nil)
}
